

<?php $__env->startSection('content'); ?>
    <div class="text-center py-10 bg-white rounded shadow">
        <h1 class="text-4xl font-bold mb-4">Welcome to Equipment Borrowing</h1>
        <p class="text-gray-600 mb-6">Borrow school equipment easily online.</p>
        <a href="/equipment" class="bg-blue-600 text-white px-6 py-3 rounded text-lg hover:bg-blue-700">Browse Equipment</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\equipment-borrowing\resources\views/home.blade.php ENDPATH**/ ?>