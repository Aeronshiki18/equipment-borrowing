<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\equipment-borrowing\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>