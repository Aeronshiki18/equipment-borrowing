<?php
namespace Tests\Feature;
use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AccessControlTest extends TestCase {
    use RefreshDatabase;

    public function test_student_cannot_access_admin_dashboard() {
        $student = User::factory()->create(['role' => 'student']);
        $response = $this->actingAs($student)->get('/admin/equipment');
        $response->assertStatus(403); // 403 means Forbidden
    }

    public function test_staff_can_access_staff_queue() {
        $staff = User::factory()->create(['role' => 'staff']);
        $response = $this->actingAs($staff)->get('/staff/requests');
        $response->assertStatus(200); // 200 means OK
    }
}