<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase; // <-- IDAGDAG ITO
use Tests\TestCase;

class ExampleTest extends TestCase
{
    use RefreshDatabase; // <-- IDAGDAG ITO PARA GUMANA

    public function test_the_application_returns_a_successful_response(): void
    {
        $response = $this->get('/');
        $response->assertStatus(200);
    }
}